package com.example.demo;


import java.util.List;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;

@SpringBootApplication
public class SpringfileReaderApplication {

	public static void main(String[] args) throws Exception {
	ConfigurableApplicationContext ctx=	SpringApplication.run(SpringfileReaderApplication.class, args);
	CSVFileReader csvFileReader=ctx.getBean(CSVFileReader.class);
	List<Product> filterProducts=csvFileReader.readFileReader();
	filterProducts.forEach(System.out::println);
		}		
	}

