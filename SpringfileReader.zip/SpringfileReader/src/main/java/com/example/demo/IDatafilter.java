package com.example.demo;

import java.util.List;

public interface IDatafilter {
 public List<Product> filterProducts(List<Product> productlist);
}
