package com.example.demo;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

@Service
public class IDataFilterImpl implements IDatafilter {

	@Override
	public List<Product> filterProducts(List<Product> productlist) {
		
		
		return productlist.stream()
				.filter(p-> p.getPrice()>5000.00)
				.collect(Collectors.toList());
	}

}
