package com.example.demo;

import java.io.BufferedReader;
import java.io.File;
//import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.ArrayList;
//import java.util.Collection;
//import java.util.Iterator;
import java.util.List;
//import java.util.ListIterator;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class CSVFileReader {
	
   private IDatafilter datafilter;
   
   @Autowired
   public CSVFileReader(IDatafilter datafilter) {
	   this.datafilter=datafilter;
   }
   public List<Product> readFileReader() throws Exception{
	   List<Product> plist=new ArrayList<Product>();
	   FileReader fr=new FileReader(new File("Product.txt"));
	   BufferedReader br=new BufferedReader(fr);
	   String linedata=br.readLine();
	   
	   while(linedata !=null) {
		   String[] str=linedata.split(",");
		   String productno=str[0];
		   String productname=str[1];
		   String price=str[2];
           
		   Product p=new Product();
           p.setProductno(Integer.parseInt(productno));
           p.setProductname(productname);
           p.setPrice(Double.parseDouble(price));
           
           plist.add(p);
           linedata=br.readLine();
	   }
	   br.close();
	   List<Product> filterProducts=datafilter.filterProducts(plist);
	return filterProducts;
	   
   }

}
