package com.sri.assignment;

public class MaxDiggBetweenNum {
	public static void findMaxDifference(int[] arr,int length) {
		int temp;
		int diff;
		for (int i = 0; i<length; i++)   
        {  
            for (int j = i + 1; j<length; j++)   
            {  
                if (arr[i] >= arr[j])   
                {  
                    temp = arr[i];  
                    arr[i] = arr[j];  
                    arr[j] = temp;  
                }  
            } 
            System.out.println(arr[i]);  
           
		  }
	 diff=arr[length-1]-arr[0];
     System.out.println("max diffrence is"+diff);
	}
	public static void main(String[] args) {
			int a[]={2, 5, 1, 7, 3, 9, 5};  
			int length=a.length;
			int b[]={ 9, 2, 12, 5, 4, 7, 3, 19, 5}; 
			int length1=b.length;
			findMaxDifference(a, length);
			findMaxDifference(b, length1);

	}

}
