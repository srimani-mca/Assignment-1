package com.sri.assignment;

public class FindLargest {

			public static int getThirdLargest(int[] a, int total){  
			int temp;  
			try {
			for (int i = 0; i < total; i++)   
			        {  
			            for (int j = i + 1; j < total; j++)   
			            {  
			                if (a[i] > a[j])   
			                {  
			                    temp = a[i];  
			                    a[i] = a[j];  
			                    a[j] = temp;  
			                }  
			            }  
			         
			       return a[total-3];  
			      }
			}
			catch(ArrayIndexOutOfBoundsException ae) {
				System.out.println("Invalid Input, array size is less than 3");
			}
			return 0;  
			}
			public static void main(String args[]){  
			int a[]={6, 8, 1, 9, 2, 1, 10};  
			int b[]={6, 8, 1, 9, 2, 1, 10, 12};  
			int c[]= {6};
			int total=a.length;
			int total1=b.length;
			int total2=c.length;
			System.out.println("Third Largest: "+getThirdLargest(a,total));  
			System.out.println("Third Largest: "+getThirdLargest(b,total1)); 
			System.out.println("Third Largest: "+getThirdLargest(c,total2)); 
            
			}  

	}


