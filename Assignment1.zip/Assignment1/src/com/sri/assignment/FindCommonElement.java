package com.sri.assignment;

public class FindCommonElement {

	public static void main(String[] args) {
		int numArray1[]= {1, 5, 10, 20, 40, 80};
		int numArray2[]= {6, 7, 20, 80, 100};
		int numArray3[]= {3, 4, 15, 20, 30, 70, 80, 120};
		for(int i = 0; i < numArray1.length; i++){
			   for(int j = 0; j < numArray2.length; j++){
				   for(int k=0;k<numArray3.length;k++) {// inner loop
			    if(numArray1[i] == numArray2[j] && numArray1[i]==numArray3[k]&&numArray2[j]==numArray3[k]){
			     System.out.println("common element are"+numArray1[i]);
			     break;
		     }
		 }
	}
 }
 }
}