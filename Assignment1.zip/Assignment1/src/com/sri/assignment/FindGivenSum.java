package com.sri.assignment;

public class FindGivenSum {

	public static void main(String[] args) {
     int a[]= {3, 6, 8, -8, 10, 8 };
     int sum=16;
     for(int i=0;i<a.length;i++)
     {
    	 for(int j=i+1;j<a.length;j++)
    	 {
    		 if(sum==(a[i]+a[j]))
    		 {
    			 System.out.println("Given pair are"+a[i]+" "+a[j]);
    		 }
    	 }
     }
	}

}
