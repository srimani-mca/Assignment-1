package com.sri.assignment;

public class SmallestPairSum {

	public static void main(String[] args) {
		int a[]= {1, 7, 2, 9, 6};
		int temp;
		int sum;
		for(int i=0;i<a.length;i++)
		{
			for(int j=i+1;j<a.length;j++)
			{
				if (a[i] > a[j])   
                {  
                    temp = a[i];  
                    a[i] = a[j];  
                    a[j] = temp;  
                }  
			}
		}
       System.out.println("smallest"+a[0]);
       System.out.println("second smallest"+a[1]);
       sum=a[0]+a[1];
       System.out.println("sum of smallest pair"+sum);

	}

}
