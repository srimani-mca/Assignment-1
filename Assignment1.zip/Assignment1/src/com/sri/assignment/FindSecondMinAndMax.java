package com.sri.assignment;

public class FindSecondMinAndMax { 
		
		public static void main(String[] args) {
		int a[]={1, 2, 5, 9, 6, 4, 7, 2};  
		int total=a.length;
		int temp;  
		for (int i = 0; i < total; i++)   
        {  
            for (int j = i + 1; j < total; j++)   
            {  
                if (a[i] > a[j])   
                {  
                    temp = a[i];  
                    a[i] = a[j];  
                    a[j] = temp;  
                }  
            }    
      }
		System.out.println("Second Largest:"+a[total-2]);
        System.out.println("Second Smallest:"+a[1]);
    }
   }



