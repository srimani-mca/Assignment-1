package com.sri.assignment;

import java.util.ArrayList;
//import java.util.Arrays;
//import java.util.HashMap;
import java.util.HashSet;
//import java.util.Set;

public class SumOfUniqueElement {
	   // This function prints all distinct elements 
	    static void sumElement(int arr[]) {
	    	int sum=0;
	    	ArrayList<Integer> all=new ArrayList<Integer>();
            for(int i=0;i<arr.length;i++) {
    	    	all.add(arr[i]);
    	    	sum=sum+arr[i];
            }
            System.out.println(all);
            System.out.println("sum of all element"+sum);
	    }
	    static void removeDuplicate(int arr[]) 
	    { 
	        // Creates an empty hashset 
	        HashSet<Integer> set = new HashSet<>(); 
	  
	        // Traverse the input array 
	        for (int i=0; i<arr.length; i++) 
	        { 
	            // If not present, then put it in hashtable and print it 
	            if (!set.contains(arr[i])) 
	            { 
	                set.add(arr[i]); 
	           } 
	        } 
            System.out.println(set); 

	    } 
	    static void printDuplicate(int arr[]) {
	    	int sum = 0;
	    for(int i=0;i<arr.length;i++) {
	    	for(int j=i+1;j<arr.length;j++) {
		    		if(arr[i]==arr[j])
		    		{
		    			System.out.println(arr[i]+","+arr[j]);
		    			sum += arr[i];
		    			
		    		}
	    	}
	    }
	    System.out.println("sum of unique elements ="+sum);	
	    }
	    	  
	    // Driver method to test above method 
	    public static void main (String[] args) 
	    { 
	        int arr[] = {1, 6, 4, 3, 2, 2, 3, 8, 1};
	        //ArrayList<Integer> listArr = new ArrayList<> (Arrays.asList(1, 6, 4, 3, 2, 2, 3, 8, 1));
	        sumElement(arr);
	        removeDuplicate(arr); 
	       printDuplicate(arr);
	        
	    } 

	 
}